const stopWords = new Set([

    "the", "is", "a", "an", "and",
    "or", "but", "of", "to", "in",
    "on", "for", "with", "as", "by",
    "at", "from", "this", "that",
    "these", "those", "it", "its",
    "are", "was", "were", "be",
    "been", "being", "has", "have",
    "had", "will", "would", "can",
    "could", "should", "may",
    "might", "do", "does", "did",
    "i", "you", "he", "she",
    "we", "they", "my", "your",
    "our", "their", "me", "him",
    "her", "them", "very", "also"

]);


function extractKeywords() {

    const text = document
        .getElementById("textInput")
        .value
        .toLowerCase();

    const result = document.getElementById("result");

    if (text.trim() === "") {

        result.innerHTML =
            "<p>Please enter some text first.</p>";

        return;
    }


    const words =
        text.match(/[a-zA-Z]+/g) || [];


    const frequency = {};


    words.forEach(word => {

        if (
            word.length > 2 &&
            !stopWords.has(word)
        ) {

            if (!frequency[word]) {
                frequency[word] = 0;
            }

            frequency[word]++;

        }

    });


    const sortedKeywords =
        Object.entries(frequency)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 15);


    if (sortedKeywords.length === 0) {

        result.innerHTML =
            "<p>No meaningful keywords found.</p>";

        return;
    }


    let html = "<h2>Top Keywords</h2>";


    sortedKeywords.forEach((item, index) => {

        const word = item[0];
        const count = item[1];

        html += `
            <div class="keyword">
                ${index + 1}.
                ${word}
                <span class="rank">
                    (${count})
                </span>
            </div>
        `;

    });


    result.innerHTML = html;
}


function clearText() {

    document.getElementById("textInput").value = "";

    document.getElementById("result").innerHTML = "";

}